const products = [
  {id:1, name: "سنگ مرمر سفید", price: 150000, image:"assets/images/marble1.jpg"},
  {id:2, name: "سنگ گرانیت مشکی", price: 200000, image:"assets/images/granite1.jpg"},
  {id:3, name: "سنگ تراورتن کرم", price: 100000, image:"assets/images/travertine1.jpg"},
];

const productsDiv = document.getElementById("products");
const cartDiv = document.getElementById("cart");
const checkoutBtn = document.getElementById("checkoutBtn");

let cart = [];

function renderProducts() {
  productsDiv.innerHTML = "";
  products.forEach(product => {
    const card = document.createElement("div");
    card.className = "product-card";
    card.innerHTML = `
      <img src="${product.image}" alt="${product.name}" />
      <h4>${product.name}</h4>
      <p>قیمت: ${product.price.toLocaleString()} تومان</p>
      <button onclick="addToCart(${product.id})">افزودن به سبد خرید</button>
    `;
    productsDiv.appendChild(card);
  });
}

function renderCart() {
  if (cart.length === 0) {
    cartDiv.innerHTML = "<p>سبد خرید شما خالی است.</p>";
    return;
  }
  let html = "<ul>";
  cart.forEach(item => {
    html += `<li>${item.name} - تعداد: ${item.qty} - قیمت کل: ${(item.price * item.qty).toLocaleString()} تومان 
      <button onclick="removeFromCart(${item.id})">حذف</button>
    </li>`;
  });
  html += "</ul>";
  cartDiv.innerHTML = html;
}

function addToCart(id) {
  const product = products.find(p => p.id === id);
  const cartItem = cart.find(item => item.id === id);
  if (cartItem) {
    cartItem.qty++;
  } else {
    cart.push({...product, qty:1});
  }
  renderCart();
}

function removeFromCart(id) {
  cart = cart.filter(item => item.id !== id);
  renderCart();
}

checkoutBtn.addEventListener("click", () => {
  if (cart.length === 0) {
    alert("سبد خرید شما خالی است.");
    return;
  }
  alert("پرداخت شبیه‌سازی شد. درگاه پرداخت به زودی اضافه می‌شود.");
});

document.addEventListener("DOMContentLoaded", () => {
  renderProducts();
  renderCart();
});
