<?php
session_start();

$correct_password = "Mm123456";

if (isset($_POST['password'])) {
    if ($_POST['password'] === $correct_password) {
        $_SESSION['admin_logged_in'] = true;
        header('Location: panel.php');
        exit();
    } else {
        $error = "رمز عبور اشتباه است.";
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
<meta charset="UTF-8" />
<title>ورود به پنل مدیریت | سنگ پرداز</title>
<style>
body { font-family: Tahoma, sans-serif; background:#f5f5f5; }
.login-container {
  max-width: 300px; margin: 100px auto; padding: 20px;
  background: white; border-radius: 8px; box-shadow: 0 0 8px #ccc;
  direction: rtl;
  text-align: center;
}
input[type="password"] {
  width: 100%; padding: 10px; margin: 10px 0; font-size: 1rem;
}
button {
  padding: 10px 20px; font-size: 1rem; cursor: pointer;
}
.error {
  color: red; margin-bottom: 10px;
}
</style>
</head>
<body>
<div class="login-container">
  <h2>ورود به پنل مدیریت</h2>
  <?php if (isset($error)) echo "<div class='error'>$error</div>"; ?>
  <form method="post" action="">
    <input type="password" name="password" placeholder="رمز عبور" required />
    <button type="submit">ورود</button>
  </form>
</div>
</body>
</html>
