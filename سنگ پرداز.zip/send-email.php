<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $to = "info@sangpardaz.ir";  // ایمیل مقصد
    $subject = "پیام جدید از فرم تماس با ما";
    $name = htmlspecialchars($_POST["name"]);
    $email = htmlspecialchars($_POST["email"]);
    $message = htmlspecialchars($_POST["message"]);

    $headers = "From: $email\r\n";
    $headers .= "Content-Type: text/plain; charset=utf-8\r\n";

    $body = "نام: $name\n";
    $body .= "ایمیل: $email\n\n";
    $body .= "پیام:\n$message\n";

    if (mail($to, $subject, $body, $headers)) {
        echo "پیام با موفقیت ارسال شد.";
    } else {
        echo "ارسال پیام با مشکل مواجه شد.";
    }
}
?>