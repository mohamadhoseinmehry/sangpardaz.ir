<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}
$messagesFile = '../messages.json';
$messages = file_exists($messagesFile) ? json_decode(file_get_contents($messagesFile), true) : [];
?>
<!DOCTYPE html>
<html lang="fa">
<head>
  <meta charset="UTF-8">
  <title>پیام‌های کاربران | مدیریت سنگ پرداز</title>
  <link rel="stylesheet" href="../css/style.css">
  <style>
    .admin-table {
      width: 90%;
      margin: 2rem auto;
      border-collapse: collapse;
      direction: rtl;
    }
    .admin-table th, .admin-table td {
      border: 1px solid #ddd;
      padding: 0.75rem;
      text-align: right;
    }
    .admin-table th {
      background-color: #f0f0f0;
    }
  </style>
</head>
<body>
  <header class="top-bar">
    <h1 class="logo">پنل مدیریت | سنگ پرداز</h1>
    <a href="login.php?logout=1" class="logout" style="float:left;color:#f88;text-decoration:none;font-weight:bold;margin-top:10px;">خروج</a>
  </header>
  <section>
    <h2 style="text-align: center; margin-top: 2rem;">لیست پیام‌های دریافتی</h2>
    <?php if (empty($messages)) : ?>
      <p style="text-align: center; color: #777;">هنوز پیامی ثبت نشده است.</p>
    <?php else : ?>
      <table class="admin-table">
        <tr>
          <th>نام</th>
          <th>ایمیل</th>
          <th>پیام</th>
          <th>تاریخ</th>
        </tr>
        <?php foreach ($messages as $msg) : ?>
          <tr>
            <td><?= htmlspecialchars($msg['name']) ?></td>
            <td><?= htmlspecialchars($msg['email']) ?></td>
            <td><?= nl2br(htmlspecialchars($msg['message'])) ?></td>
            <td><?= $msg['date'] ?></td>
          </tr>
        <?php endforeach; ?>
      </table>
    <?php endif; ?>
  </section>
  <footer>
    <p style="text-align:center; margin-top:2rem; color:#666">© 2025 سنگ پرداز | پنل مدیریت</p>
  </footer>
</body>
</html>
