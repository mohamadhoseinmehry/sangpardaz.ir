<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
<meta charset="UTF-8" />
<title>پنل مدیریت | سنگ پرداز</title>
<link rel="stylesheet" href="../css/style.css" />
<style>
  body {direction: rtl; font-family: Tahoma, sans-serif;}
  header.top-bar {
    background: #222; color: white; padding: 15px 20px;
  }
  a.logout {
    float: left; color: #f88; text-decoration: none; font-weight: bold;
    margin-top: 10px;
  }
</style>
</head>
<body>
<header class="top-bar">
  <h1 class="logo">پنل مدیریت | سنگ پرداز</h1>
  <a href="login.php?logout=1" class="logout">خروج</a>
</header>
<main>
  <section>
    <h2 style="text-align: center; margin-top: 2rem;">به پنل مدیریت خوش آمدید</h2>
    <p style="text-align:center;">اینجا می‌توانید پیام‌های دریافتی و مدیریت سایت را انجام دهید.</p>
  </section>
</main>
<footer>
  <p style="text-align:center; margin-top:2rem; color:#666">© 2025 سنگ پرداز | پنل مدیریت</p>
</footer>
</body>
</html>
